================================================================
  SOUL Learning System - Teacher Device Setup
================================================================

This package installs the SOUL Learning CA certificate so your
browser can securely connect to the SOUL teacher dashboard
without security warnings.

After installing, access the teacher dashboard at:
  https://soul.local:3001

Make sure your device is connected to the same WiFi network
as the SOUL classroom server.


INSTALLATION INSTRUCTIONS
================================================================

WINDOWS:
--------
1. Extract this ZIP file
2. Right-click "install-windows.bat"
3. Select "Run as administrator"
4. Follow the prompts
5. Open Chrome/Edge and go to https://soul.local:3001


MAC:
----
1. Extract this ZIP file
2. Double-click "install-mac.command"
3. Enter your Mac password when prompted
4. Open Safari/Chrome and go to https://soul.local:3001


CHROMEOS (with Linux enabled):
------------------------------
1. Extract this ZIP file to your Linux files
2. Open the Linux Terminal
3. Run: chmod +x install-chromeos.sh && ./install-chromeos.sh
4. Restart Chrome
5. Go to https://soul.local:3001


iOS (iPad/iPhone):
------------------
1. Transfer "install-ios.mobileconfig" to your iOS device
   (via AirDrop, email, or download from website)
2. Open the file - it will prompt to install a profile
3. Go to Settings > General > VPN & Device Management
4. Tap "SOUL Learning System - Teacher Setup"
5. Tap "Install" and enter your passcode
6. IMPORTANT: Go to Settings > General > About >
   Certificate Trust Settings
7. Enable "Full Trust" for "SOUL Learning CA"
8. Open Safari and go to https://soul.local:3001


TROUBLESHOOTING
================================================================

"Cannot connect to soul.local"
- Make sure you're on the same WiFi as the SOUL server
- Try using the IP address instead: https://192.168.1.10:3001

"Certificate warning still appears"
- Restart your browser after installing the certificate
- On iOS, make sure you enabled "Full Trust" in settings

Need help? Contact your school's SOUL administrator.

================================================================
