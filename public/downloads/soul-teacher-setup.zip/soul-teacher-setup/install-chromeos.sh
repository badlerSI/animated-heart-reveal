#!/bin/bash
# SOUL Learning System - Certificate Installer for ChromeOS Linux
# Run this in the Linux terminal on your Chromebook

echo "================================================================"
echo "  SOUL Learning System - Certificate Installer for ChromeOS"
echo "================================================================"
echo ""
echo "This will install the SOUL Learning CA certificate so Chrome"
echo "can securely connect to the SOUL teacher dashboard."
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CERT_FILE="$SCRIPT_DIR/SOUL-Learning-CA.crt"

if [ ! -f "$CERT_FILE" ]; then
    echo "Error: Certificate file not found!"
    echo "Expected: $CERT_FILE"
    exit 1
fi

# Check if libnss3-tools is installed
if ! command -v certutil &> /dev/null; then
    echo "Installing required tools (libnss3-tools)..."
    sudo apt-get update -qq
    sudo apt-get install -y libnss3-tools
fi

# Create NSS database if it doesn't exist
echo "Setting up certificate database..."
mkdir -p ~/.pki/nssdb

# Initialize database if needed
if [ ! -f ~/.pki/nssdb/cert9.db ]; then
    certutil -d sql:$HOME/.pki/nssdb -N --empty-password
fi

# Import the certificate
echo "Installing certificate..."
certutil -d sql:$HOME/.pki/nssdb -A -t "C,," -n "SOUL Learning CA" -i "$CERT_FILE"

if [ $? -eq 0 ]; then
    echo ""
    echo "================================================================"
    echo "  Installation Complete!"
    echo "================================================================"
    echo ""
    echo "IMPORTANT: Please restart Chrome for changes to take effect."
    echo ""
    echo "You can then access the SOUL Teacher Dashboard at:"
    echo "  https://soul.local:3001"
    echo ""
    echo "Make sure you are connected to the same WiFi as the SOUL server."
else
    echo ""
    echo "Error: Installation failed. Please try again."
fi
